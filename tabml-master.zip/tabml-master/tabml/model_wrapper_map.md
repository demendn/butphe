# Inheritance map

- <class '__main__.BaseModelWrapper'>
    - <class '__main__.BaseBoostingModelWrapper'>
        - <class '__main__.BaseCatBoostModelWrapper'>
            - <class '__main__.CatBoostRegressorModelWrapper'>
            - <class '__main__.CatBoostClassifierModelWrapper'>
        - <class '__main__.BaseXGBoostModelWrapper'>
            - <class '__main__.XGBoostClassifierModelWrapper'>
            - <class '__main__.XGBoostRegressorModelWrapper'>
        - <class '__main__.BaseLgbmModelWrapper'>
            - <class '__main__.LgbmRegressorModelWrapper'>
            - <class '__main__.LgbmClassifierModelWrapper'>
    - <class '__main__.BaseSklearnModelWrapper'>
